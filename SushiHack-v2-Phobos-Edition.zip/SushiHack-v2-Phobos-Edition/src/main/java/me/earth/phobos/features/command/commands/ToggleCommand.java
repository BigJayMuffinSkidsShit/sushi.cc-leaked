package me.earth.phobos.features.command.commands;

import me.earth.phobos.SushiHack;
import me.earth.phobos.features.command.Command;
import me.earth.phobos.features.modules.Module;
import me.earth.phobos.manager.ModuleManager;
import me.earth.phobos.util.TextUtil;

import java.io.File;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ToggleCommand
        extends Command {
    public ToggleCommand() {
        super("toggle", new String[]{"<module>"});
    }

    @Override
    public void execute(String[] commands) {

        if (commands.length == 1) {
            ToggleCommand.sendMessage("Provide the name of the module to toggle!");
            return;
        }
        if (commands.length == 2) {
            Module module = SushiHack.moduleManager.getModuleByName(commands[0]);

            if(module != null) {
                module.toggle();
                if(module.isOn()) {
                    ToggleCommand.sendMessage(module.getName() + TextUtil.GREEN + TextUtil.BOLD + " enabled!");
                } else {
                    ToggleCommand.sendMessage(module.getName() + TextUtil.RED + TextUtil.BOLD + " disabled!");
                }

            } else {
                ToggleCommand.sendMessage("Module " + commands[0] + " not found!");
            }

        }
    }
}

