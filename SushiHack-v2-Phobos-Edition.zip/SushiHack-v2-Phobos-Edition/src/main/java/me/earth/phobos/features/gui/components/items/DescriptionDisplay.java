package me.earth.phobos.features.gui.components.items;

import me.earth.phobos.SushiHack;
import me.earth.phobos.util.RenderUtil;

public class DescriptionDisplay extends Item {
    private String description;
    private boolean draw;

    public DescriptionDisplay(String description, float x, float y) {
        super("DescriptionDisplay");

        this.description = description;

        this.setLocation(x, y);
        this.width = SushiHack.textManager.getStringWidth(this.description) + 4;
        this.height = SushiHack.textManager.getFontHeight() + 4;

        this.draw = false;
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        this.width = SushiHack.textManager.getStringWidth(this.description) + 4;
        this.height = SushiHack.textManager.getFontHeight() + 4;

        RenderUtil.drawRect(this.x, this.y, this.x + this.width, this.y + this.height, 0xd6000000);
        SushiHack.textManager.drawString(this.description, this.x + 2, this.y + 2, 0xffffff, true);
    }

    public boolean shouldDraw() {
        return this.draw;
    }
    public String getDescription() { return this.description; }

    public void setDraw(boolean draw) {
        this.draw = draw;
    }
    public void setDescription(String description) { this.description = description; }
}
