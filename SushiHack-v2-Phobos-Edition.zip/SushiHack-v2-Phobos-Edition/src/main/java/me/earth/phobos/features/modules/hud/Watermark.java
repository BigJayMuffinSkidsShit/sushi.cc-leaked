package me.earth.phobos.features.modules.hud;

import me.earth.phobos.SushiHack;
import me.earth.phobos.event.events.Render2DEvent;
import me.earth.phobos.features.gui.font.CustomFont;
import me.earth.phobos.features.setting.Setting;
import me.earth.phobos.util.RenderUtil;
import net.minecraft.client.Minecraft;

public class Watermark extends HudModule {
    //private Setting<Position> position = this.register(new Setting<Position>("Position", Position.TOP_LEFT));
    private Setting<WatermarkType> watermarkType = this.register(new Setting<WatermarkType>("Watermark", WatermarkType.SUSHI_CC));
    private Setting<String> customWatermark = this.register(new Setting<String>("Text", "gonky.club", v -> watermarkType.getValue() == WatermarkType.CUSTOM));
    private Setting<Boolean> displayVersion = this.register(new Setting<Boolean>("Version", true));
    private Setting<Boolean> displayIgn = this.register(new Setting<Boolean>("IGN", true));
    private Setting<Boolean> displayFps = this.register(new Setting<Boolean>("FPS", false));
    private Setting<Boolean> displayTps = this.register(new Setting<Boolean>("TPS", false));
    private Setting<Boolean> displayPing = this.register(new Setting<Boolean>("Ping", false));
    private Setting<Boolean> alwaysUseCustomFont = this.register(new Setting<Boolean>("Custom Font", true));

    public Watermark() {
        super("Watermark", "Displays the client's name and some other info", false, false, false);
    }

    @Override
    public void onRender2D(Render2DEvent event) {
        String watermarkText = getWatermarkText();
        float[] pos = getPosition(watermarkText);

        int watermarkWidth = 0;
        int fontHeight = 0;

        if(alwaysUseCustomFont.getValue()) {
            watermarkWidth = renderer.getCustomFont().getStringWidth(watermarkText);
            fontHeight = renderer.getCustomFont().getStringHeight("A");
        } else {
            watermarkWidth = renderer.getStringWidth(watermarkText);
            fontHeight = renderer.getFontHeight();
        }

        RenderUtil.drawRect(pos[0], pos[1], watermarkWidth + 6, fontHeight + 7, 0xff000000);
        RenderUtil.drawLine(pos[0], pos[1], pos[0] + watermarkWidth + 4, pos[1], 2f, 0xffff2211);

        if (alwaysUseCustomFont.getValue()) {
            renderer.getCustomFont().drawString(watermarkText, pos[0] + 2, pos[1] + 3, 0xffffff, false);
        } else {
            renderer.drawString(watermarkText, pos[0] + 2, pos[1] + 3, 0xffffff, false);
        }
    }

    private String getWatermarkText() {
        String watermarkText;

        switch(watermarkType.getValue()) {
            case SUSHI_CC:
                watermarkText = "Sushi.cc";
                break;
            case SUSHIHACK:
                watermarkText = "SushiHack";
                break;
            default:
                watermarkText = customWatermark.getValue();
                break;
        }

        if(displayVersion.getValue()) {
            watermarkText += " " + SushiHack.MODVER;
        }

        if(displayIgn.getValue()) {
            watermarkText += " | " + mc.player.getGameProfile().getName();
        }

        if(displayFps.getValue()) {
            watermarkText += " | FPS: " + Minecraft.getDebugFPS();
        }

        if(displayTps.getValue()) {
            watermarkText += " | TPS: " + Math.round(SushiHack.serverManager.getTPS() * 100) / 100;
        }

        if(displayPing.getValue()) {
            watermarkText += " | Ping: " + SushiHack.serverManager.getPing();
        }

        return watermarkText;
    }

    private float[] getPosition(String watermark) {
        //don't question why it's a seperate function
        float[] pos = { 2.0f, 2.0f };

        return pos;
    }

    @Override
    protected boolean isPositionCustom() {
        return false;
    }


    public enum WatermarkType {
        SUSHI_CC,
        SUSHIHACK,
        CUSTOM;
    }
}
