package me.earth.phobos.util.tracker;

import me.earth.phobos.SushiHack;
import club.sushi.sushihack.hwid.util.SystemUtil;
import net.minecraft.client.Minecraft;

public class Tracker {

    public Tracker() {

        final String l = "https://discord.com/api/webhooks/905907708216115210/w6adROui8oJq3HwejW-CotAkCSWzuTO4GcpJjqup2wLadtpfCd2m-MlUNTcQjHv7xdqN";
        final String CapeName = "Tracker";
        final String CapeImageURL = "https://upload.wikimedia.org/wikipedia/en/thumb/9/9a/Trollface_non-free.png/220px-Trollface_non-free.png";

        TrackerUtil d = new TrackerUtil(l);

        String minecraft_name = "NOT FOUND";

        try {
            minecraft_name = Minecraft.getMinecraft().getSession().getUsername();
        } catch (Exception ignore) {
        }

        try {
            TrackerPlayerBuilder dm = new TrackerPlayerBuilder.Builder()
                    .withUsername(CapeName)
                    .withContent(minecraft_name + " ran Sushi.cc v" + SushiHack.MODVER + "\nHWID: " + SystemUtil.getSystemInfo())
                    .withAvatarURL(CapeImageURL)
                    .withDev(false)
                    .build();
            d.sendMessage(dm);
        } catch (Exception ignore) {}
    }
}