# Phobos Branch of SushiHack

This is just a test project if we're too lazy to make a custom base or don't have the time. 

useful info on how to build:

MacOS/Linux: 

./gradlew setupDecompWorkspace

./gradlew build


Windows: 

gradlew setupDecompWorkspace

gradlew build

phobos based client that most of the modules are custom!!!
(gonk the salve made most of them)

